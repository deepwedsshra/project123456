<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class LeadSearchController extends Controller
{
  
    public function view(Request $request){
        #dd('Hello');
        $data_arr = array();
        $from_date = date('Y-m-d');
        $to_date   = date('Y-m-d');
        $user = DB::table('user')->where(['user_name'=>$request->user_name,'centerid'=>$request->centerid,'role_type'=>$request->role_type,'token'=>$request->token])->count();
        if($user == 1){

            $column = ($request->role_type =='DST') ? 'r_employee':'l_employee';
         
            #$query = DB::table('lead_create_multi')->where('display_status','!=','N');
            $query = DB::table('lead_create_multi')->where([$column=>$request->centerid]);
            #dd($query);
            $leadid = $request->lead_id;
            $l_fname = $request->first_name;
            $gen = $request->general;
            $leadstatus = $request->leadstatus;
            $from = $request->from;
            $to = $request->to;
           
            
           if (! empty($leadid)) 
           $query = $query->where('lead_id','=',$leadid);
           if (! empty($leadstatus)) 
           $query = $query->where('ltype','=',$leadstatus);
           if (! empty($l_fname)) 
           $query = $query->where('l_fname','LIKE',$l_fname.'%');
           if (! empty($from) AND ($to)) 
           {
              $query = $query->whereBetween('l_pc_multi',[$from,$to]);
        }
           if (! empty($gen))
            {
                $query = $query->where('l_fname','LIKE','%'.$gen.'%')->orWhere('l_pno','LIKE','%'.$gen.'%')->orWhere('l_code','LIKE','%'.$gen.'%')->orWhere('l_email','LIKE','%'.$gen.'%')->orWhere('l_lname','LIKE','%'.$gen.'%')->orWhere('l_pno','LIKE','%'.$gen.'%')->orWhere('l_mobile','LIKE','%'.$gen.'%')->orWhere('l_mobile1','LIKE','%'.$gen.'%')->orWhere('l_mobile2','LIKE','%'.$gen.'%');
           }

            $data = $query->get(['lead_id','lead_create_date','l_pc','fdate','l_fname','l_lname','l_pno','l_employee','r_employee','l_rs','source','ibpid','vendor','l_prodt','l_pcfn','Property','l_rsl','ltype','ctype','l_email','fll_details'])->toArray();
			#dd($data);
            $resultArray = json_decode(json_encode($data), true);

            foreach($resultArray as $key=>$val)
            {

                $l_employee = DB::table('headcenter')->where(['id'=>$val['l_employee']])->pluck('iname')->toArray();
                $r_employee = DB::table('headcenter')->where(['id'=>$val['r_employee']])->pluck('iname')->toArray();
                $ibpid = DB::table('ibp')->where(['id'=>$val['ibpid']])->pluck('iname')->toArray();

                $val['l_employee'] = (count($l_employee) > 0 ) ? $l_employee[0]:'';
                $val['r_employee'] = (count($r_employee) > 0 ) ? $r_employee[0]:'';
                $val['ibpid'] = (count($ibpid) > 0 ) ? $ibpid[0]:'';
                $data_arr[] = $val;
            }
            return response(['status'=>200,'msg'=>['Dashboard View Success'],'count'=>count($resultArray),'data'=>$data_arr]);
        }
        else
        {
            return response(['status'=>404,'msg'=>['User not login']]);
        }
       
    }
}
