<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class Home extends Controller
{
    public function index(Request $request){
        //dd($request->id);
        $cp = $request->id;
        if($cp == '')
        {
            return view('home');    
        } 
        else
        {
            $categoryname = DB::table('ibp')->where(['micro_status'=>'Enable','slogan'=>$cp])->pluck('id')->toArray();
				$cp_id = (count($categoryname) > 0 ) ? $categoryname[0]:'';
                    if($cp_id == '')
                    {
                        return view('home');
                    }
                    else
                    {
                        $data1 = DB::table('ibp')->where(['id'=>$cp_id])->get(['id','iname','iadd','itel','ihand','iemail','iage','ipan','owner','m_fb','m_tw','m_ld','m_yt','m_mo','m_wno','m_ig','slogan'])->first();
			            //$data = json_decode(json_encode($data1), true);
                        $data = compact('data1');
                        return view('home')->with($data);
                        #dd($data);
                    }

        }


                

    }
	
}
   
