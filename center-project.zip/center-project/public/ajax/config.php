<?php

$servername = "localhost";
$username = "leads_all";
$password = "(i-f11CGFixO";
$dbname ="mix_leads";


// try {
// 	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
// 	// set the PDO error mode to exception
// 	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// // 	echo "Connected successfully";
// } catch (PDOException $e) {
// 	echo "Connection failed: " . $e->getMessage();
// }

$euname = 'admin@rohavatika.com';

$projectname="Roha Vatika";

$url  = "https://antalicatowers.comrohavatika.com/";

?>