<?php
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

ob_start();
session_start();
$response = array();
$validation = "";

include('UserInfo.php');

$ip         = UserInfo::get_ip();
$device     = UserInfo::get_device();
$os         = UserInfo::get_os();
$browser    = UserInfo::get_browser();

$json     = file_get_contents("http://ipinfo.io/$ip/geo");
$json     = json_decode($json, true);
$country  = $json['country'];
$region   = $json['region'];
$city     = $json['city'];

$location= $region. "-" .$city;

header('Content-type: application/json; charset=UTF-8');
include 'config.php';
date_default_timezone_set('Asia/Kolkata');
$date = date("j F Y, g:i a");
if ($_POST){
if ($_POST['submit']==='pageload') {
    if(!empty($_POST['utm_campaign'])){$utm_campaign = $_POST['utm_campaign'];}else{ $utm_campaign = '';}
    if(!empty($_POST['utm_medium'])){$utm_medium = $_POST['utm_medium'];}else{$utm_medium = '';  }
    if(!empty($_POST['utm_source'])){$utm_source = $_POST['utm_source'];}else{$utm_source = '';}
    if(!empty($_POST['utm_term'])){$utm_term = $_POST['utm_term'];}else{$utm_term = ''; }
    if(!empty($_POST['utm_content'])){$utm_content = $_POST['utm_content'];}else{$utm_content= '';}
    if(!empty($_POST['initial_referrer'])){$initial_referrer = strip_tags($_POST['initial_referrer']);}else{$initial_referrer= '';}
    if(!empty($_POST['last_referrer'])){$last_referrer = strip_tags($_POST['last_referrer']);}else{$last_referrer= '';}
    if(!empty($_POST['initial_landing_page'])){$initial_landing_page = strip_tags($_POST['initial_landing_page']);}else{$initial_landing_page= '';}
    if(!empty($_POST['visits'])){$visits = $_POST['visits'];}else{$visits= '';}

	$name 	= $_POST['name'];
	$email 	= $_POST['email'];
	$phone  = $_POST['mobile'];
	$cpidmain  = $_POST['cpidmain'];
	$page = $_SERVER['HTTP_REFERER'];
    
	if (empty(trim($name))) {
		$validation .= "Please enter name </br>";
	} else if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
		$validation .= "Only letters and white space allowed</br>";
	} else if ($name === "test" || $name === "demo" || $name === "user") {
		$validation .= "Plese Specify valid name</br>";
	}

	if (empty(trim($email))) {
		$validation .= "Please enter email </br>";
	} else {
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$validation .= "Invalid email format <br>";
		}
	}

	if (empty(trim($phone))) {
		$validation .= "Please enter phone </br>";
	} else if (!is_numeric($phone)) {
		$validation .= "Please enter only digits !</br>";
	} else if (!preg_match("/^[7890]\d{9}/", $phone)) {
		$validation .= "Please enter valid number</br>";
	} else if (strlen($phone) != 10) {
		$validation .= "phone number 10 digits only ! </br>";
	}



	if (!empty($validation)) {
		$response['status'] = 'error';
		$response['message'] = $validation;
		echo json_encode($response);
		exit();
	}
	
	$_SESSION['form']=time();
	    $_SESSION['pageload']='yes';
	    $subject = 'Auto reply from '.$projectname.'.';

		$messageBody = "<html><body>";
		$messageBody .= "Dear " . $name . ",<br><br>";
		$messageBody .= "Thank you for contacting us. This is to confirm that your message has been received by us on date " . $date . ".<br><br>The details provided by you were as mentioned below-<br><br>";
		$messageBody .= "<strong>Name  </strong><strong> : </strong>" . $name . "<br>";
		$messageBody .= "<strong>Email Id.  </strong><strong> : </strong>" . $email . "<br>";
		$messageBody .= "<strong>Mobile No. </strong><strong> : </strong>" . $phone . "<br><br>";

		$messageBody .= "We will be replying to you shortly. <br><br>";
		$messageBody .= "<strong>Thanks & Regards, <br> ".$projectname."</strong> <br>";
    	$messageBody .= "</body></html>";
    	$header       = "From: Roha Vatika <admin@rohavatika.com> \r\n";
		$header      .= "MIME-Version: 1.0\r\n";
		$header      .= "Content-type: text/html; charset=iso-8859-1 \r\n";

		if (!mail($email, $subject, $messageBody, $header)) {
		    $response['status'] = 'eroor';
			$response['message'] = "1- Mailer Error: ";
			echo json_encode($response);
		} else {
			$Admsubject = 'Enquiry for Get in Touch';
			$AdmmessageBody = "<html><body>";
			$AdmmessageBody .= "<h2><u>".$projectname. " Website: Get in Touch Enquiry</u></h2></br>The details provided by the enquirer are mentioned below:<br><br>";
			$AdmmessageBody .= "<strong>Name  </strong><strong> : </strong>" . $name . "<br>";
			$AdmmessageBody .= "<strong>Email Id  </strong><strong> : </strong>" . $email . "<br>";
			$AdmmessageBody .= "<strong>Mobile No.  </strong><strong> : </strong>" . $phone . "<br>";

			$AdmmessageBody .= "Enquirer is awaiting your reply.";
			$AdmmessageBody .= "</body></html>";
			
            $header1       = "From: Roha Vatika <admin@rohavatika.com> \r\n";
			$header1       = "Bcc: Roha Vatika <smusale42@gmail.com> \r\n";
		    $header1      .= "MIME-Version: 1.0\r\n";
		    $header1      .= "Content-type: text/html; charset=iso-8859-1 \r\n";
			if (!mail($euname, $Admsubject, $AdmmessageBody, $header1)) {
				$response['status'] = 'eroor';
				$response['message'] = "2 - Mailer Error: ";
			} else {
				$response['status'] = 'success';
				$response['message'] = "Thank you for your response";
				$response['redirecturl'] = $_SERVER['HTTP_REFERER'];

			}
				echo json_encode($response);
		}


 }else if($_POST['submit']==='enquiry'){
    if(!empty($_POST['utm_campaign'])){$utm_campaign = $_POST['utm_campaign'];}else{ $utm_campaign = '';}
    if(!empty($_POST['utm_medium'])){$utm_medium = $_POST['utm_medium'];}else{$utm_medium = '';  }
    if(!empty($_POST['utm_source'])){$utm_source = $_POST['utm_source'];}else{$utm_source = '';}
    if(!empty($_POST['utm_term'])){$utm_term = $_POST['utm_term'];}else{$utm_term = ''; }
    if(!empty($_POST['utm_content'])){$utm_content = $_POST['utm_content'];}else{$utm_content= '';}
    if(!empty($_POST['initial_referrer'])){$initial_referrer = strip_tags($_POST['initial_referrer']);}else{$initial_referrer= '';}
    if(!empty($_POST['last_referrer'])){$last_referrer = strip_tags($_POST['last_referrer']);}else{$last_referrer= '';}
    if(!empty($_POST['initial_landing_page'])){$initial_landing_page = strip_tags($_POST['initial_landing_page']);}else{$initial_landing_page= '';}
    if(!empty($_POST['visits'])){$visits = $_POST['visits'];}else{$visits= '';}

	$name 	= $_POST['name'];
	$email 	= $_POST['email'];
	$phone  = $_POST['mobile'];
	$page = $_SERVER['HTTP_REFERER'];
    
	if (empty(trim($name))) {
		$validation .= "Please enter name </br>";
	} else if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
		$validation .= "Only letters and white space allowed</br>";
	} else if ($name === "test" || $name === "demo" || $name === "user") {
		$validation .= "Plese Specify valid name</br>";
	}

	if (empty(trim($email))) {
		$validation .= "Please enter email </br>";
	} else {
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$validation .= "Invalid email format <br>";
		}
	}

	if (empty(trim($phone))) {
		$validation .= "Please enter phone </br>";
	} else if (!is_numeric($phone)) {
		$validation .= "Please enter only digits !</br>";
	} else if (!preg_match("/^[7890]\d{9}/", $phone)) {
		$validation .= "Please enter valid number</br>";
	} else if (strlen($phone) != 10) {
		$validation .= "phone number 10 digits only ! </br>";
	}



	if (!empty($validation)) {
		$response['status'] = 'error';
		$response['message'] = $validation;
		echo json_encode($response);
		exit();
	}
	

	$_SESSION['form']=time();
	$subject = 'Auto reply from '.$projectname.'.';
	
	$messageBody = "<html><body>";
	$messageBody .= "Dear " . $name . ",<br><br>";
	$messageBody .= "Thank you for contacting us. This is to confirm that your message has been received by us on date " . $date . ".<br><br>The details provided by you were as mentioned below-<br><br>";
	$messageBody .= "<strong>Name  </strong><strong> : </strong>" . $name . "<br>";
	$messageBody .= "<strong>Email Id.  </strong><strong> : </strong>" . $email . "<br>";
	$messageBody .= "<strong>Mobile No. </strong><strong> : </strong>" . $phone . "<br>";

	$messageBody .= "We will be replying to you shortly. <br><br>";
	$messageBody .= "<strong>Thanks & Regards, <br> ".$projectname."</strong> <br>";
	$messageBody .= "</body></html>";
	$header       = "From: Roha Vatika <admin@rohavatika.com> \r\n";
	$header      .= "MIME-Version: 1.0\r\n";
	$header      .= "Content-type: text/html; charset=iso-8859-1 \r\n";

	if (!mail($email, $subject, $messageBody, $header)) {
		$response['status'] = 'eroor';
		$response['message'] = "1- Mailer Error: ";
		echo json_encode($response);
	} else {
		$Admsubject = 'Enquiry for Get in Touch';
		$AdmmessageBody = "<html><body>";
		$AdmmessageBody .= "<h2><u>".$projectname. " Website: Get in Touch Enquiry</u></h2></br>The details provided by the enquirer are mentioned below:<br><br>";
		$AdmmessageBody .= "<strong>Name  </strong><strong> : </strong>" . $name . "<br>";
		$AdmmessageBody .= "<strong>Email Id  </strong><strong> : </strong>" . $email . "<br>";
		$AdmmessageBody .= "<strong>Mobile No.  </strong><strong> : </strong>" . $phone . "<br>";
		$AdmmessageBody .= "Enquirer is awaiting your reply.";
		$AdmmessageBody .= "</body></html>";
		
		$header1       = "From: Roha Vatika <admin@rohavatika.com> \r\n";
		$header1       = "Bcc: Roha Vatika <smusale42@gmail.com> \r\n";
		$header1      .= "MIME-Version: 1.0\r\n";
		$header1      .= "Content-type: text/html; charset=iso-8859-1 \r\n";
		if (!mail($euname, $Admsubject, $AdmmessageBody, $header1)) {
			$response['status'] = 'eroor';
			$response['message'] = "2 - Mailer Error: ";
		} else {
			$response['status'] = 'success';
			$response['message'] = "Thank you for your response";
			$response['redirecturl'] = $_SERVER['HTTP_REFERER'];

		}
			echo json_encode($response);
	}
 }else if($_POST['submit']==='PriceForm'){
    if(!empty($_POST['utm_campaign'])){$utm_campaign = $_POST['utm_campaign'];}else{ $utm_campaign = '';}
    if(!empty($_POST['utm_medium'])){$utm_medium = $_POST['utm_medium'];}else{$utm_medium = '';  }
    if(!empty($_POST['utm_source'])){$utm_source = $_POST['utm_source'];}else{$utm_source = '';}
    if(!empty($_POST['utm_term'])){$utm_term = $_POST['utm_term'];}else{$utm_term = ''; }
    if(!empty($_POST['utm_content'])){$utm_content = $_POST['utm_content'];}else{$utm_content= '';}
    if(!empty($_POST['initial_referrer'])){$initial_referrer = strip_tags($_POST['initial_referrer']);}else{$initial_referrer= '';}
    if(!empty($_POST['last_referrer'])){$last_referrer = strip_tags($_POST['last_referrer']);}else{$last_referrer= '';}
    if(!empty($_POST['initial_landing_page'])){$initial_landing_page = strip_tags($_POST['initial_landing_page']);}else{$initial_landing_page= '';}
    if(!empty($_POST['visits'])){$visits = $_POST['visits'];}else{$visits= '';}

	$name 	= $_POST['name'];
	$email 	= $_POST['email'];
	$phone  = $_POST['mobile'];
	
	$tower      = $_POST['tower'];
	$config     = $_POST['con'];
	$salearea   = $_POST['salearea'];
	$carpetarea = $_POST['carpetarea'];
	$price      = $_POST['pprice'];
	$possession = $_POST['possession'];
	
	$floorname = $_POST['floorname'];
	$floorplan = $_POST['flooreplan'];
	$page = $_SERVER['HTTP_REFERER'];
    
	if (empty(trim($name))) {
		$validation .= "Please enter name </br>";
	} else if (!preg_match("/^[a-zA-Z ]*$/", $name)) {
		$validation .= "Only letters and white space allowed</br>";
	} else if ($name === "test" || $name === "demo" || $name === "user") {
		$validation .= "Plese Specify valid name</br>";
	}

	if (empty(trim($email))) {
		$validation .= "Please enter email </br>";
	} else {
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$validation .= "Invalid email format <br>";
		}
	}

	if (empty(trim($phone))) {
		$validation .= "Please enter phone </br>";
	} else if (!is_numeric($phone)) {
		$validation .= "Please enter only digits !</br>";
	} else if (!preg_match("/^[7890]\d{9}/", $phone)) {
		$validation .= "Please enter valid number</br>";
	} else if (strlen($phone) != 10) {
		$validation .= "phone number 10 digits only ! </br>";
	}



	if (!empty($validation)) {
		$response['status'] = 'error';
		$response['message'] = $validation;
		echo json_encode($response);
		exit();
	}
	
	if(empty($floorname)){$floor ="<br>"; $newsource=$source;}else{$floor ="<strong>Floor Name.  </strong><strong> : </strong>" . $floorname . "<br>"; $newsource="Floor Plan Form";}
	if(empty($floorplan)){$floorp ="";}else{$floorp="<strong>Floor Plan.  </strong><strong> : </strong>" . $floorplan . "<br>";}
	
    $price_con = "<strong>Tower Name : </strong>" .$tower. "<br><strong> Configuration : </strong>" .$config. " <br><strong> Saleable Area </strong> :" .$salearea. "<br> <strong> Carpet Area : </strong>" .$carpetarea. "<br><strong> Price :</strong>" .$price. "<br><strong> Possession : </strong>" .$possession ;
	$price_con1 = "Tower Name : " .$tower. "<br> Configuration : " .$config. " <br> Saleable Area :" .$salearea. "<br> Carpet Area : " .$carpetarea. "<br> Price :" .$price. "<br> Possession : " .$possession ;
	
	
	$_SESSION['form']=time();
	$subject = 'Auto reply from '.$projectname.'.';
	
	$messageBody = "<html><body>";
	$messageBody .= "Dear " . $name . ",<br><br>";
	$messageBody .= "Thank you for contacting us. This is to confirm that your message has been received by us on date " . $date . ".<br><br>The details provided by you were as mentioned below-<br><br>";
	$messageBody .= "<strong>Name  </strong><strong> : </strong>" . $name . "<br>";
	$messageBody .= "<strong>Email Id.  </strong><strong> : </strong>" . $email . "<br>";
	$messageBody .= "<strong>Mobile No. </strong><strong> : </strong>" . $phone . "<br>";
	$messageBody .= $price_con;

	$messageBody .= "<br>We will be replying to you shortly. <br><br>";
	$messageBody .= "<strong>Thanks & Regards, <br> ".$projectname."</strong> <br>";
	$messageBody .= "</body></html>";
	$header       = "From: Roha Vatika <admin@rohavatika.com> \r\n";
	$header      .= "MIME-Version: 1.0\r\n";
	$header      .= "Content-type: text/html; charset=iso-8859-1 \r\n";

	if (!mail($email, $subject, $messageBody, $header)) {
		$response['status'] = 'eroor';
		$response['message'] = "1- Mailer Error: ";
		echo json_encode($response);
	} else {
		$Admsubject = 'Enquiry for Get in Touch';
		$AdmmessageBody = "<html><body>";
		$AdmmessageBody .= "<h2><u>".$projectname. " Website: Get in Touch Enquiry</u></h2></br>The details provided by the enquirer are mentioned below:<br><br>";
		$AdmmessageBody .= "<strong>Name  </strong><strong> : </strong>" . $name . "<br>";
		$AdmmessageBody .= "<strong>Email Id  </strong><strong> : </strong>" . $email . "<br>";
		$AdmmessageBody .= "<strong>Mobile No.  </strong><strong> : </strong>" . $phone . "<br>";
		$AdmmessageBody .= $price_con;
		$AdmmessageBody .= "<br>Enquirer is awaiting your reply.";
		$AdmmessageBody .= "</body></html>";
		
		$header1       = "From: Roha Vatika <admin@rohavatika.com> \r\n";
		$header1       = "Bcc: Roha Vatika <smusale42@gmail.com> \r\n";
		$header1      .= "MIME-Version: 1.0\r\n";
		$header1      .= "Content-type: text/html; charset=iso-8859-1 \r\n";
		if (!mail($euname, $Admsubject, $AdmmessageBody, $header1)) {
			$response['status'] = 'eroor';
			$response['message'] = "2 - Mailer Error: ";
		} else {
			$response['status'] = 'success';
			$response['message'] = "Thank you for your response";
			$response['redirecturl'] = $_SERVER['HTTP_REFERER'];

		}
			echo json_encode($response);
	}


 }else{
    $response['status'] = 'error';
	$response['message'] = "Somthing is wrong";
    echo json_encode($response);
 }
 }
 else {header("Location:https://rohavatika.com/");}
?>