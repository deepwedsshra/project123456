<?php
require'inc/connect.php';
#header("Access-Control-Allow-Origin: *");
#header("Content-Type: application/json; charset=UTF-8");
#header("Access-Control-Allow-Methods: POST");
#header("Access-Control-Max-Age: 3600");
#header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
  

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");



 //$callidd = $_GET['data'];
error_reporting(0);

#print_r($_REQUEST);
#EXIT;
 // echo 'hello';
 date_default_timezone_set('Asia/Kolkata');
$datetime = date('Y-m-d H:i:s');
    //$data = (array)json_decode(urldecode($callidd));

$l_fname = $_GET['fname'];
$l_lname = $_GET['lname'];
$l_pno1 = $_GET['contactno'];
$l_pno2 = str_replace("+","",$l_pno1);
  $date12= date("Y-m-d H:i:s");
   $l_pc= date("Y-m-d H:i:s");

$l_pno3 = strlen($l_pno2);

if($l_pno3 == 11)
{
	$l_pno2 = '0'.$l_pno2.'';
}
if($l_pno3 == 10)
{
	$l_pno2 = '91'.$l_pno2.'';
}

$l_pno = $l_pno2;




$l_prodt = $_GET['project'];
$l_ld = $_GET['comment'];
$l_ld = mysqli_real_escape_string($con,$l_ld);
$medium = $_GET['medium'];
$l_email = $_GET['email'];
$vendor = $_GET['vendor'];
$utm_campaign = $_GET['utm_campaign'];
 if($medium == '')
 {
	 $source = 'Website';
 }
 else
 {
	 $source = $medium ; 
 }
 
 
 if($source == 'facebook')
 {
	 $source = 'Facebook';
 }
 
  if($source == 'google' OR $source == 'Google' OR  $source == 'Google' )
 {
	 $source = 'google';
 }
 
 
 /*
 if($source == 'google' OR $source == 'Google' OR  $source == 'Google' )
 {
	 $source = 'google';
 }
*/





$sql1rdre_rr="SELECT id,smid FROM lead_create_rrobin where id='1'";
	
	$data1gffg_rr =  mysqli_query($con,$sql1rdre_rr);
	$rowddffdfd_rr = mysqli_fetch_array($data1gffg_rr);
	$sm_user_rrd =  $rowddffdfd_rr['smid'];


if($l_pno != '')
{	

if($sm_user_rrd == '5')
{
	$centerid = '18';
}

else
{
$centerid = '5';
}


$query1_dfdffd = mysqli_query($con,"SELECT * FROM lead_create WHERE ".$l_pno." IN(l_pno,l_mobile,l_mobile1,l_mobile2)");
$fetch_rows1 = mysqli_num_rows($query1_dfdffd);

if($fetch_rows1 == 0 )
{
	
	

$str = "update lead_create_rrobin set smid = '".$centerid."' where id='1'";
		  $rs = mysqli_query($con,$str);	

	
  $sql1rdre="SELECT id,user_name FROM user where centerid=".$centerid." and status='a' and type='c'";
	
	$data1gffg =  mysqli_query($con,$sql1rdre);
	$rowddffdfd = mysqli_fetch_array($data1gffg);
	$sm_user =  $rowddffdfd['user_name'];
	$user_name =  $rowddffdfd['user_name'];
	$sessionname =  $rowddffdfd['id'];
	$sessionshop =  $rowddffdfd['user_name'];
   
	  $dis = "select * from headcenter where id=$centerid";
									$run = mysqli_query($con,$dis);
									$row = mysqli_fetch_assoc($run);
									
										$izone = $row['izone'];
	$iregion = $row['iregion'];
	

	$idivision = $row['idivision'];
	$icenter = $row['icenter'];
	$centernname = $row['centernname'];
    $contact = $row['contact'];
	$whatsapp = $row['whatsapp'];
	$landmark = $row['landmark'];
	$pincode = $row['pincode'];
	$iname = $row['iname'];
	$iadd = $row['iadd'];
	$ioadd = $row['ioadd'];
	$itel = $row['itel'];
	$ihand = $row['ihand'];
	$iemail = $row['iemail'];
	$owner = $row['owner'];		
    $role = $row['role'];		
    $roledd = $row['role'];		
	
					
								
								$dis = "select id,mul_procode from  products where pro_name = '".$l_prodt."'";
									$run_proid = mysqli_query($con,$dis);
									$i = 1;
									$row_proid = mysqli_fetch_array($run_proid);
									
										$row_proid_proid = $row_proid['id'];
										$mul_procode = $row_proid['mul_procode'];
								
	//$Property = implode(',', $_GET['Property']);
	$centerid_dst = '';
		$centerid = $centerid;
		$ll_details = 'On this lead For Project '.$l_prodt.' '.$sm_user.' is been allocated .';
		$ll_details1 = 'Enquiry - '.$l_ld.' .';

	  $redate= date("Y-m-d");
	  $date12= date("Y-m-d H:i:s");
	  $l_pc= date("Y-m-d H:i:s");
  $retime= date("H:i:s");
$user_table_name = 'System';
$user_table_id = 'System';
$user_id1 = 'System';
	$ivoter = 'System';
	$sm_user_fill = 'System';
	$sessionname = 'System';
	$sessionshop = 'System';
	
  $lead_date= date("Y-m-d");
  $lead_date15 =  date('Y-m-d', strtotime(' + 15 days')); 
  $lead_date30 =  date('Y-m-d', strtotime(' + 30 days')); 
  $lead_date45 =  date('Y-m-d', strtotime(' + 45 days')); 
  $lead_date60 =  date('Y-m-d', strtotime(' + 60 days')); 
  $lead_date75 =  date('Y-m-d', strtotime(' + 75 days')); 
  $lead_date90 =  date('Y-m-d', strtotime(' + 90 days')); 
  $lead_date105 =  date('Y-m-d', strtotime(' + 105 days')); 
  
  $sql="insert into lead_create (`ltype`,`l_pjln`,`r_employee`,`l_employee`,`izone`, `iregion`,`idivision`, `icenter`, `ibpid`,`l_prodt`,`l_bid`,`l_code`,`l_fname`,`l_lname`,`l_jtitle`,`l_email`,`l_pno`,`l_company`,`l_tfd`,`l_itos`,`l_rs`,`l_rsl`,`l_hqc`,`l_lhs`,`l_hc`,`l_ld`,`l_pcfn`,`l_pcln`,`l_pce`,`l_pcn`,`l_pcn1`,`l_pcn2`,`l_pcn3`,`l_pc`,`Property`,`adv`,`loca`,`pref`,`prof`,`eadd`,dtime,`smid`,`smmobile`,`source`,`vendor`,`lead_upload_date`,`lead_create_date`,`lead_update_date`,`lead_all_date`,`allocation_id`,`v_userid`,`v_username`,`v_date`,`status3`,`first_comment_date`,`last_comment_date`,`l_mobile`,`l_mobile1`,`l_mobile2`,`lead_allo_date`,`lead_allo_time`,`mul_proid`,`mul_proname`,`mul_procode`,`pre_mul_proid`,`pre_mul_proname`,`pre_mul_procode`,`purpose`, `lead_date`, `lead_date15`, `lead_date30`, `lead_date45`, `lead_date60`, `lead_date75`, `lead_date90`, `lead_date105`)VALUES('','$l_pjln','$centerid_dst','$centerid','$izone', '$iregion', '$idivision', '$icenter', '','$l_prodt','$l_bid','$l_code','$l_fname','$l_lname', '$l_jtitle','$l_email', '$l_pno','$l_company','$l_tfd','$l_itos','$l_rs','$l_rsl','$l_hqc','$l_lhs','$l_hc','$l_ld','$l_pcfn','$l_pcln','$l_pce','$l_pcn','$l_pcn1','$l_pcn2','$l_pcn3','$l_pc','$Property','$adv','$loca','$pref','$prof','$eadd',NOW(),'$centerid','$ihand','$source','$vendor','$date12','$date12','$date12','$date12','$user_id1','$user_table_id','$user_table_name','$v_date','$ibpid','$date12','$date12','$l_mobile','$l_mobile1','$l_mobile2','$redate','$retime','$row_proid_proid','$l_prodt','$mul_procode','$row_proid_proid','$l_prodt','$mul_procode','$new_purpse', '$lead_date', '$lead_date15', '$lead_date30', '$lead_date45', '$lead_date60', '$lead_date75', '$lead_date90', '$lead_date105')";
 
 $rs = mysqli_query($con,$sql);
  $billid =  mysqli_insert_id( $con);
  $row_lead_id =  mysqli_insert_id( $con);
 
   $str11="INSERT INTO lead_create_multi( `l_code`, `l_fname`, `l_lname`, `l_jtitle`, `l_email`, `l_pno`, `l_company`, `l_tfd`, `l_itos`, `l_rs`, `l_rsl`, `l_hqc`, `l_lhs`, `l_hc`, `l_ld`, `l_pcfn`, `l_pcln`, `l_pce`, `l_pcn`, `l_pc3`, `l_employee`, `l_mydate`, `l_mydate1`, `status`, `l_bid`, `izone`, `iregion`, `idivision`, `icenter`, `ibpid`, `l_prodt`, `Property`, `l_pcn1`, `l_pcn2`, `l_pcn3`, `fDate`, `fTime`, `dtime`, `mil`, `type`, `ltype`, `adv`, `loca`, `pref`, `prof`, `eadd`, `smid`, `l_mobile`, `smmobile`, `source`, `vendor`, `r_employee`, `comment`, `uploadcomment`, `user_name`, `status2`, `status3`, `ctype`, `site_visit1`, `site_visit2`, `lead_upload_date`, `lead_create_date`, `lead_update_date`, `lead_all_date`, `first_comment_date`, `last_comment_date`, `lead_auto_date`, `dst_first_comment`, `dst_last_comment`, `booking_date`, `booking_amt`, `booking_due`, `booking_per`, `due_per`, `due_clearation_date`, `allocation_id`, `dst_qualifty`, `cl_sm_status`, `reid`, `allocation_id1`, `log_update_date`, `v_userid`, `v_username`, `v_date`, `l_pc`, `l_pc2`, `l_pjln`, `fll_details`, `fll_fillby`, `fsub`, `stype`, `site_update_date`, `stype1`, `sale_update_date`, `dead_update_date`, `l_mobile1`, `l_mobile2`, `r_employee_pre`, `l_employee_pre`, `reallocation`, `redate`, `retime`, `pav_an`, `pav_can1`, `pav_can2`, `pav_can3`, `pav_av`, `pav_proid`, `pav_wing`, `pav_rno`, `pav_comm`, `pav_gst`, `pav_ordernoani`, `pav_fundtype`, `pav_bookdate`, `pav_cn`, `av_an`, `av_can1`, `av_can2`, `av_can3`, `av_av`, `av_proid`, `av_wing`, `av_rno`, `av_comm`, `av_gst`, `av_ordernoani`, `av_fundtype`, `av_bookdate`, `av_cn`, `av_other_charges`, `av_ibptype`, `av_custid`, `av_type`, `lead_allo_date`, `lead_allo_time`, `dead_status`, `dead_time`, `dsm`, `dst_name`, `d_employee`,`mul_cp`,`mul_cpsm`,`mul_dst`,`mul_proid`,`mul_proname`, `lead_id`, `mul_source`, `mul_procode`, `mul_vendor`, `lead_create_multi_date`,`l_pc_multi`,`purpose`, `lead_date`, `lead_date15`, `lead_date30`, `lead_date45`, `lead_date60`, `lead_date75`, `lead_date90`, `lead_date105`) 
  
  SELECT  l_code, l_fname, l_lname, l_jtitle, l_email, l_pno, l_company, l_tfd, l_itos, l_rs, l_rsl, l_hqc, l_lhs, l_hc, l_ld, l_pcfn, l_pcln, l_pce, l_pcn, l_pc3, l_employee, l_mydate, l_mydate1, status, l_bid, izone, iregion, idivision, icenter, ibpid, l_prodt, Property, l_pcn1, l_pcn2, l_pcn3, fDate, fTime, dtime, mil, type, ltype, adv, loca, pref, prof, eadd, smid, l_mobile, smmobile, source, vendor, r_employee, comment, uploadcomment, user_name, status2, status3, ctype, site_visit1, site_visit2, lead_upload_date, lead_create_date, lead_update_date, lead_all_date, first_comment_date, last_comment_date, lead_auto_date, dst_first_comment, dst_last_comment, booking_date, booking_amt, booking_due, booking_per, due_per, due_clearation_date, allocation_id, dst_qualifty, cl_sm_status, reid, allocation_id1, log_update_date, v_userid, v_username, v_date, l_pc, l_pc2, l_pjln, fll_details, fll_fillby, fsub, stype, site_update_date, stype1, sale_update_date, dead_update_date, l_mobile1, l_mobile2, r_employee_pre, l_employee_pre, reallocation, redate, retime, pav_an, pav_can1, pav_can2, pav_can3, pav_av, pav_proid, pav_wing, pav_rno, pav_comm, pav_gst, pav_ordernoani, pav_fundtype, pav_bookdate, pav_cn, av_an, av_can1, av_can2, av_can3, av_av, av_proid, av_wing, av_rno, av_comm, av_gst, av_ordernoani, av_fundtype, av_bookdate, av_cn, av_other_charges, av_ibptype, av_custid, av_type, lead_allo_date, lead_allo_time, dead_status, dead_time, dsm, dst_name, d_employee,'$ibpid','$centerid','$centerid_dst','$row_proid_proid','$l_prodt', '$row_lead_id', '$source', '$mul_procode', '$vendor', '$date12', '$date12', '$new_purpse', `lead_date`, `lead_date15`, `lead_date30`, `lead_date45`, `lead_date60`, `lead_date75`, `lead_date90`, `lead_date105` FROM lead_create WHERE id='".$row_lead_id."'";
		
		$rs11 = mysqli_query($con,$str11);
  $str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `Date`, `Time`, `dtime`, `ltype`, `ctype`, `sm_id`, `admin_id`, `rece_id`,`mul_proid`,`mul_proname`,`mul_procode`) values
  
 ('', '$ll_details', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', '', '', '', '', '', '', '', '$centerid', '', '','$row_proid_proid','$l_prodt','$mul_procode')";
		 mysqli_query( $con,$str11);
		 
		 if($ll_details1 != '')
		 {
		$str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `Date`, `Time`, `dtime`, `ltype`, `ctype`, `sm_id`, `admin_id`, `rece_id`,`mul_proid`,`mul_proname`,`mul_procode`) values
  
 ('', '$ll_details1', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', '', '', '', '', '', '', '', '$centerid', '', '','$row_proid_proid','$l_prodt','$mul_procode')";
		 mysqli_query( $con,$str11);
		 }
		 $sql1= "INSERT INTO w3_lead_calling(`callid`,`callfrom`,`starttime`,`calid`,`pulse`,`source`,`custfeedback`,`exefeedback`,`callerbusiness`,`callername`,`remark`,`calleraddress`,`caller_email`,`rate`,`empnumber`,`endtime`,`eid`,`empid`,`gid`,`empemail`,`regoin`,`filename`) VALUES ('$callid','$l_pno','$starttime','$calid','$pulse','$source','$custfeedback','$exefeedback','$callerbusiness','$l_lname','$ll_details','$calleraddress','$l_email','$rate','$empnumber','$endtime','$eid','$empid','$gid','$empemail','$regoin','$filename')";
 mysqli_query( $con,$sql1);

		

 $int="INSERT INTO `enquiry_kasturi` (`fname`, `lname`, `contactno`, `project`, `comment`, `medium`, `email`, `vendor`) VALUES ('".$l_fname."', '".$l_lname."', '".$l_pno."', '".$l_prodt."', '".$l_ld."', '".$source."', '".$l_email."', '".$vendor."')";
$query1 = mysqli_query( $con,$int);
								
	
	


}


else
{
	
	
	
	
	
$rowadd = mysqli_fetch_array($query1_dfdffd);
	$leadidani = $rowadd['id'];
	$row_lead_id = $rowadd['id'];
	$leadid = $rowadd['id'];
	
	
	$dis = "select id,mul_procode from  products where pro_name = '".$l_prodt."'";
									$run_proid = mysqli_query($con,$dis);
									$i = 1;
									$row_proid = mysqli_fetch_array($run_proid);
									
										$row_proid_proid = $row_proid['id'];
										$mul_procode = $row_proid['mul_procode'];
								
	
  $redate= date("Y-m-d");
$retime= date("H:i:s");
 $date12 = date('Y-m-d H:i:s');
	//new Code
	
	$sql1gfggf = "select lead_id from lead_create_multi where lead_id='".$row_lead_id."' AND  mul_proid='".$row_proid_proid."'   ";
$display1ggffg= mysqli_query($con,$sql1gfggf) ;
$fetch_rows1_else = mysqli_num_rows($display1ggffg);
if ( $fetch_rows1_else > 0 )
{
	
$rowaddfdfddf = mysqli_fetch_assoc($display1ggffg);
$ctype_multi = $rowaddfdfddf['ctype'];
$ltype_multi = $rowaddfdfddf['ltype'];
$source_multi = $rowaddfdfddf['source'];
$r_employee_multi = $rowaddfdfddf['r_employee'];
$l_employee_multi = $rowaddfdfddf['l_employee'];
$ibpid_multi = $rowaddfdfddf['ibpid'];
$smmobile_multi = $rowaddfdfddf['smmobile'];
$ltype_multi = $rowaddfdfddf['ltype'];
$ltype_multi = $rowaddfdfddf['ltype'];

 $date12= date("Y-m-d H:i:s");
	
	  $dis = "select * from headcenter where id=$centerid";
									$run = mysqli_query($con,$dis);
									$row = mysqli_fetch_array($run);
								
										$izone = $row['izone'];
	$iregion = $row['iregion'];
	

	$idivision = $row['idivision'];
	$icenter = $row['icenter'];
	$centernname = $row['centernname'];
    $contact = $row['contact'];
	$whatsapp = $row['whatsapp'];
	$landmark = $row['landmark'];
	$pincode = $row['pincode'];
	$iname = $row['iname'];
	$iadd = $row['iadd'];
	$ioadd = $row['ioadd'];
	$itel = $row['itel'];
	$ihand = $row['ihand'];
	$iemail = $row['iemail'];
	$owner = $row['owner'];		
	$role = $row['role'];		
	
								
								
									$sql1rdre="SELECT id,user_name FROM user where centerid=".$centerid." and status='a' and type='c'";
	
	$data1gffg =  mysqli_query($con,$sql1rdre);
	$rowddffdfd = mysqli_fetch_array($data1gffg);
	$sm_user =  $rowddffdfd['user_name'];
	$user_name =  $rowddffdfd['user_name'];
   
				$sessionname = 'System';
	$sessionshop = 'System';
	 $user_table_id = 'System';
     $user_table_name = 'System';
     $username11 = 'System';
	if($role == 'DST')
	{
		
		$centerid_dst = $centerid;
		$centerid = '';
		$ibpid = '';
		$ll_details = 'On this lead For Project '.$l_prodt.' '.$sm_user.' is been allocated.';
	}
	else
	{
		$centerid_dst = '';
		$centerid = $centerid;
		$ibpid = $ibpid;
		$ll_details = 'On this lead For Project '.$l_prodt.' '.$sm_user.' is been allocated.';
  }
  
  $pre_source = $source;
  $mul_vendor = $vendor;
  
  
	$sm_user_fill = 'System';




////Inner condition in if loop
if($ctype_multi == 'Lost' OR $ltype_multi == 'Lost')
	
	{
			$ll_details1 = 'On this lead For Project '.$l_prodt.' Source Changed From  '.$source_multi.' to '.$pre_source.' by  '.$username11.' ';

	
		$ll_details = 'On this lead For Project '.$l_prodt.' Source '.$pre_source.' '.$sm_user.' is been allocated.';
		

	
          $str = "update lead_create set  l_employee_pre='".$l_employee_multi."', r_employee_pre='".$r_employee_multi."', pre_cp='".$ibpid_multi."', pre_source='".$source_multi."',r_employee = '',l_employee = '',ibpid = '',source = '',vendor = '',smmobile = '' where id='".$row_lead_id."'";
		  $rs = mysqli_query($con,$str);				
								
 			 $str = "update lead_create set r_employee = '".$centerid_dst."',l_employee = '".$centerid."',ibpid = '".$ibpid."',source = '".$pre_source."',vendor = '".$mul_vendor."',mul_proid = '".$row_proid_proid."',mul_proname = '".$l_prodt."',l_prodt = '".$l_prodt."',mul_procode = '".$mul_procode."',ltype = '',ctype = '',fDate = '',fTime = '',dtime = '',fll_details = '',fll_fillby = '' where id='".$row_lead_id."'";
		  $rs = mysqli_query($con,$str);					

			
							
		  $str = "update lead_create_multi set l_itos = '',l_rs = '',l_rsl = '',l_hqc = '',l_lhs = '',l_hc = '',l_pcfn = '',l_pcln = '',l_pce = '',l_pcn = '',l_pc3 = '',l_mydate = '".$date12."',smmobile = '".$smmobile."',l_mydate1 = '".$date12."',lead_auto_date = '".$date12."',lead_upload_date = '".$date12."',lead_create_date = '".$date12."',lead_update_date = '".$date12."',lead_allo_time = '".$retime."',lead_allo_date = '".$date12."',lead_all_date = '".$date12."',v_date = '".$date12."',l_pc = '".$date12."',l_pcn1 = '',l_pcn2 = '',l_pcn3 = '',loca = '',pref = '',prof = '',eadd = '',site_visit1 = '',site_visit2 = '',first_comment_date = '',last_comment_date = '',dst_first_comment = '',dst_last_comment = '',booking_date = '',booking_amt = '',booking_due = '',booking_per = '',due_per = '',dst_qualifty = '',cl_sm_status = '',reid = '',allocation_id1 = '',log_update_date = '',v_userid = '".$user_table_id."',v_username = '".$user_table_name."',stype = '',site_update_date = '',stype1 = '',sale_update_date = '',dead_update_date = '',l_mobile1 = '',l_mobile2 = '',r_employee_pre = '".$r_employee_multi."',l_employee_pre='".$l_employee_multi."',reallocation = '".$username11."',redate = '".$redate."',retime = '".$retime."',pav_an = '',pav_can1 = '',pav_can2 = '',pav_can3 = '',pav_av = '',pav_proid = '',pav_wing = '',pav_rno = '',pav_comm = '',pav_gst = '',pav_ordernoani = '',pav_fundtype = '',pav_bookdate = '',pav_cn = '',av_an = '',av_can1 = '',av_can2 = '',av_can3 = '',av_av = '',av_proid = '',av_wing = '',av_rno = '',av_comm = '',av_gst = '',av_ordernoani = '',av_fundtype = '',av_bookdate = '',av_cn = '',av_other_charges = '',av_ibptype = '',av_custid = '',dead_status = '',dead_time = '',dsm = '',dst_name = '',d_employee = '',r_employee = '',l_employee = '',ibpid = '',source = '',vendor = '', pre_cp='".$ibpid_multi."', pre_source='".$source_multi."' where lead_id='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'";
		  $rs = mysqli_query($con,$str);				
			
	     $str = "update lead_create_multi set r_employee = '".$centerid_dst."',l_employee = '".$centerid."',ibpid = '".$ibpid."',source = '".$pre_source."',vendor = '".$mul_vendor."',mul_proid = '".$row_proid_proid."',mul_proname = '".$l_prodt."',l_prodt = '".$l_prodt."',mul_procode = '".$mul_procode."',ltype = '',ctype = '',fDate = '',fTime = '',dtime = '',fll_details = '',fll_fillby = '' where lead_id='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'";
		  $rs = mysqli_query($con,$str);	
		
		  $str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `sm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`, `Date`, `Time`, `dtime`, `ltype`, `ctype`) 
     SELECT `sub`, '$ll_details1', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, '$centerid', `admin_id`, `rece_id`, '','$row_proid_proid','$l_prodt','$mul_procode', '', '', '', '', '' FROM lead_log WHERE ll_leadid='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'    ORDER BY id DESC  limit 1";
		
		 $rs = mysqli_query($con,$str11);
		
 $str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `sm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`, `Date`, `Time`, `dtime`, `ltype`, `ctype`) 
     SELECT `sub`, '$ll_details', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, '$centerid', `admin_id`, `rece_id`, '','$row_proid_proid','$l_prodt','$mul_procode', '', '', '', '', '' FROM lead_log WHERE ll_leadid='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'    ORDER BY id DESC  limit 1";
		
		 $rs = mysqli_query($con,$str11);
		

		
		
		
		
	}

else
	
	{
		
		
$date12 = date('Y-m-d H:i:s');
$Date = date('Y-m-d');
$iadd = 'Customer Again Enquiry with comment '.$l_ld.' from '.$source.'';
$ll_details = 'Customer Again Enquiry with comment '.$l_ld.' from '.$source.'';
	$ivoter = 'System';
	$sm_user_fill = 'System';
	$sessionname = 'System';
	$sessionshop = 'System';
	
	
		
		 $str = "update lead_create set ltype = '',ctype = '',fDate = '',fTime = '',dtime = '',fll_details = '',fll_fillby = '' where id='".$row_lead_id."'";
		  $rs = mysqli_query($con,$str);					

			 $str = "update lead_create_multi set ltype = '',ctype = '',fDate = '',fTime = '',dtime = '',fll_details = '',fll_fillby = '' where lead_id='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'";
		  $rs = mysqli_query($con,$str);					

			
		
		
		
		$str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `sm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`, `Date`, `Time`, `dtime`, `ltype`, `ctype`) 
     SELECT `sub`, '$ll_details', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, '$centerid', `admin_id`, `rece_id`, '','$row_proid_proid','$l_prodt','$mul_procode', '', '', '', '', '' FROM lead_log WHERE ll_leadid='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'    ORDER BY id DESC  limit 1";
		
		 $rs = mysqli_query($con,$str11);
		

		
		
	}
////End Inner condition in if loop
	
	

}
//////If Conditionend for exsting active lead



else
{
	
	
	  $dis = "select * from headcenter where id=$centerid";
									$run = mysqli_query($con,$dis);
									$row = mysqli_fetch_array($run);
								
										$izone = $row['izone'];
	$iregion = $row['iregion'];
	

	$idivision = $row['idivision'];
	$icenter = $row['icenter'];
	$centernname = $row['centernname'];
    $contact = $row['contact'];
	$whatsapp = $row['whatsapp'];
	$landmark = $row['landmark'];
	$pincode = $row['pincode'];
	$iname = $row['iname'];
	$iadd = $row['iadd'];
	$ioadd = $row['ioadd'];
	$itel = $row['itel'];
	$ihand = $row['ihand'];
	$iemail = $row['iemail'];
	$owner = $row['owner'];		
	$role = $row['role'];		
	
								
								
									$sql1rdre="SELECT id,user_name FROM user where centerid=".$centerid." and status='a' and type='c'";
	
	$data1gffg =  mysqli_query($con,$sql1rdre);
	$rowddffdfd = mysqli_fetch_array($data1gffg);
	$sm_user =  $rowddffdfd['user_name'];
	$user_name =  $rowddffdfd['user_name'];
   
				$sessionname = 'System';
	$sessionshop = 'System';
	 $user_table_id = 'System';
     $user_table_name = 'System';
	if($role == 'DST')
	{
		
		$centerid_dst = $centerid;
		$centerid = '';
		$ll_details = 'On this lead For Project '.$l_prodt.' '.$sm_user.' is been allocated.';
		$ll_details1 = 'Enquiry - '.$l_ld.' .';

	}
	else
	{
		$centerid_dst = '';
		$centerid = $centerid;
		$ll_details = 'On this lead For Project '.$l_prodt.' '.$sm_user.' is been allocated.';
		$ll_details1 = 'Enquiry - '.$l_ld.' .';

  }
  
  $pre_source = $source;
  $mul_vendor = $vendor;
  
  
  $redate= date("Y-m-d");
$retime= date("H:i:s");
 $date12 = date('Y-m-d H:i:s');
  $str11="INSERT INTO lead_create_multi( `l_code`, `l_fname`, `l_lname`, `l_jtitle`, `l_email`, `l_pno`, `l_company`, `l_tfd`, `l_itos`, `l_rs`, `l_rsl`, `l_hqc`, `l_lhs`, `l_hc`, `l_ld`, `l_pcfn`, `l_pcln`, `l_pce`, `l_pcn`, `l_pc3`, `l_employee`, `l_mydate`, `l_mydate1`, `status`, `l_bid`, `izone`, `iregion`, `idivision`, `icenter`, `ibpid`, `l_prodt`, `Property`, `l_pcn1`, `l_pcn2`, `l_pcn3`, `mil`, `type`,  `adv`, `loca`, `pref`, `prof`, `eadd`, `smid`, `l_mobile`, `smmobile`, `source`, `vendor`, `r_employee`, `comment`, `uploadcomment`, `user_name`, `status2`, `status3`,  `site_visit1`, `site_visit2`, `lead_upload_date`, `lead_create_date`, `lead_update_date`, `lead_all_date`, `first_comment_date`, `last_comment_date`, `lead_auto_date`, `dst_first_comment`, `dst_last_comment`, `booking_date`, `booking_amt`, `booking_due`, `booking_per`, `due_per`, `due_clearation_date`, `allocation_id`, `dst_qualifty`, `cl_sm_status`, `reid`, `allocation_id1`, `log_update_date`, `v_userid`, `v_username`, `v_date`, `l_pc`, `l_pc2`, `l_pjln`, `fsub`, `stype`, `site_update_date`, `stype1`, `sale_update_date`, `dead_update_date`, `l_mobile1`, `l_mobile2`, `r_employee_pre`, `l_employee_pre`, `reallocation`, `redate`, `retime`, `pav_an`, `pav_can1`, `pav_can2`, `pav_can3`, `pav_av`, `pav_proid`, `pav_wing`, `pav_rno`, `pav_comm`, `pav_gst`, `pav_ordernoani`, `pav_fundtype`, `pav_bookdate`, `pav_cn`, `av_an`, `av_can1`, `av_can2`, `av_can3`, `av_av`, `av_proid`, `av_wing`, `av_rno`, `av_comm`, `av_gst`, `av_ordernoani`, `av_fundtype`, `av_bookdate`, `av_cn`, `av_other_charges`, `av_ibptype`, `av_custid`, `av_type`, `lead_allo_date`, `lead_allo_time`, `dead_status`, `dead_time`, `dsm`, `dst_name`, `d_employee`,`mul_cp`,`mul_cpsm`,`mul_dst`,`mul_proid`,`mul_proname`, `lead_id`, `mul_source`, `mul_procode`, `mul_vendor`, `lead_create_multi_date`,`l_pc_multi`,`lead_date`, `lead_date15`, `lead_date30`, `lead_date45`, `lead_date60`, `lead_date75`, `lead_date90`, `lead_date105`) 
  
  
  SELECT  l_code, l_fname, l_lname, l_jtitle, l_email, l_pno, l_company, l_tfd, l_itos, l_rs, l_rsl, l_hqc, l_lhs, l_hc, l_ld, l_pcfn, l_pcln, l_pce, l_pcn, l_pc3, '$centerid', l_mydate, l_mydate1, status, l_bid, izone, iregion, idivision, icenter, '$ibpid', '$l_prodt', Property, l_pcn1, l_pcn2, l_pcn3, mil, type,  adv, loca, pref, prof, eadd, smid, l_mobile, smmobile, '$pre_source', '$mul_vendor', '$centerid_dst', comment, uploadcomment, user_name, status2, status3,  site_visit1, site_visit2, lead_upload_date, lead_create_date, lead_update_date, lead_all_date, first_comment_date, last_comment_date, lead_auto_date, dst_first_comment, dst_last_comment, booking_date, booking_amt, booking_due, booking_per, due_per, due_clearation_date, allocation_id, dst_qualifty, cl_sm_status, reid, allocation_id1, log_update_date, v_userid, v_username, v_date, '$date12', l_pc2, l_pjln, fsub, stype, site_update_date, stype1, sale_update_date, dead_update_date, l_mobile1, l_mobile2, r_employee_pre, l_employee_pre, reallocation, redate, retime, pav_an, pav_can1, pav_can2, pav_can3, pav_av, pav_proid, pav_wing, pav_rno, pav_comm, pav_gst, pav_ordernoani, pav_fundtype, pav_bookdate, pav_cn, av_an, av_can1, av_can2, av_can3, av_av, av_proid, av_wing, av_rno, av_comm, av_gst, av_ordernoani, av_fundtype, av_bookdate, av_cn, av_other_charges, av_ibptype, av_custid, av_type, lead_allo_date, lead_allo_time, dead_status, dead_time, dsm, dst_name, d_employee,'$ibpid','$centerid','$centerid_dst','$row_proid_proid','$l_prodt', '$row_lead_id', '$pre_source', '$mul_procode', '$mul_vendor', '$date12', '$date12', '$lead_date', '$lead_date15', '$lead_date30', '$lead_date45', '$lead_date60', '$lead_date75', '$lead_date90', '$lead_date105' FROM lead_create WHERE id='".$row_lead_id."'";
		
		$rs11 = mysqli_query($con,$str11);
		
		
		
		
		
		
$ivoter = 'System';
	$sm_user_fill = 'System';
		if($role == 'DST')
	{
		 $str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `csm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`) 
  
  SELECT `sub`, '$ll_details', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, '$centerid_dst', `admin_id`, `rece_id`, `cp_id`,'$row_proid_proid','$l_prodt','$mul_procode' FROM lead_log WHERE ll_leadid='".$row_lead_id."' limit 1";
		
		$rs11 = mysqli_query($con,$str11); 
		
		
		$str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `csm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`) 
  
  SELECT `sub`, '$ll_details1', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, '$centerid_dst', `admin_id`, `rece_id`, `cp_id`,'$row_proid_proid','$l_prodt','$mul_procode' FROM lead_log WHERE ll_leadid='".$row_lead_id."' limit 1";
		
		$rs11 = mysqli_query($con,$str11);
	}
	else
	{
	 $str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `sm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`) 
  
  SELECT `sub`, '$ll_details', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, '$centerid', `admin_id`, `rece_id`, `cp_id`,'$row_proid_proid','$l_prodt','$mul_procode' FROM lead_log WHERE ll_leadid='".$row_lead_id."' limit 1";
		
		$rs11 = mysqli_query($con,$str11);	 
		
		$str11="INSERT INTO lead_log(`sub`, `ll_details`,`ll_fillby`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `sm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`) 
  
  SELECT `sub`, '$ll_details1', '$sm_user_fill', '$sessionname', '$sessionshop', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, '$centerid', `admin_id`, `rece_id`, `cp_id`,'$row_proid_proid','$l_prodt','$mul_procode' FROM lead_log WHERE ll_leadid='".$row_lead_id."' limit 1";
		
		$rs11 = mysqli_query($con,$str11);	
	}

	
          $str = "update lead_create set r_employee = '',l_employee = '',ibpid = '',source = '',vendor = '' where id='".$row_lead_id."'";
		  $rs = mysqli_query($con,$str);				
								
 			 $str = "update lead_create set lead_count = lead_count+1,r_employee = '".$centerid_dst."',l_employee = '".$centerid."',ibpid = '".$ibpid."',source = '".$pre_source."',vendor = '".$pre_vendor."',mul_proid = '".$row_proid_proid."',mul_proname = '".$l_prodt."',l_prodt = '".$l_prodt."',mul_procode = '".$mul_procode."',ltype = '',ctype = '',fDate = '',fTime = '',dtime = '',fll_details = '',fll_fillby = '' where id='".$row_lead_id."'";
		  $rs = mysqli_query($con,$str);					

			
							
		  $str = "update lead_create_multi set l_itos = '',l_rs = '',l_rsl = '',l_hqc = '',l_lhs = '',l_hc = '',l_ld = '".$l_ld."',l_pcfn = '',l_pcln = '',l_pce = '',l_pcn = '',l_pc3 = '',l_mydate = '".$date12."',smmobile = '".$smmobile."',l_mydate1 = '".$date12."',lead_auto_date = '".$date12."',lead_upload_date = '".$date12."',lead_create_date = '".$date12."',lead_update_date = '".$date12."',lead_allo_time = '".$retime."',lead_allo_date = '".$date12."',lead_all_date = '".$date12."',v_date = '".$date12."',l_pc = '".$date12."',Property = '',l_pcn1 = '',l_pcn2 = '',l_pcn3 = '',loca = '',pref = '',prof = '',eadd = '',comment = '',uploadcomment = '',site_visit1 = '',site_visit2 = '',first_comment_date = '',last_comment_date = '',dst_first_comment = '',dst_last_comment = '',booking_date = '',booking_amt = '',booking_due = '',booking_per = '',due_per = '',dst_qualifty = '',cl_sm_status = '',reid = '',allocation_id1 = '',log_update_date = '',v_userid = '".$user_table_id."',v_username = '".$user_table_name."',stype = '',site_update_date = '',stype1 = '',sale_update_date = '',dead_update_date = '',l_mobile1 = '',l_mobile2 = '',r_employee_pre = '',l_employee_pre = '',reallocation = '',redate = '',retime = '',pav_an = '',pav_can1 = '',pav_can2 = '',pav_can3 = '',pav_av = '',pav_proid = '',pav_wing = '',pav_rno = '',pav_comm = '',pav_gst = '',pav_ordernoani = '',pav_fundtype = '',pav_bookdate = '',pav_cn = '',av_an = '',av_can1 = '',av_can2 = '',av_can3 = '',av_av = '',av_proid = '',av_wing = '',av_rno = '',av_comm = '',av_gst = '',av_ordernoani = '',av_fundtype = '',av_bookdate = '',av_cn = '',av_other_charges = '',av_ibptype = '',av_custid = '',dead_status = '',dead_time = '',dsm = '',dst_name = '',d_employee = '',r_employee = '',l_employee = '',ibpid = '',source = '',vendor = '' where lead_id='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'";
		  $rs = mysqli_query($con,$str);				
			
	     $str = "update lead_create_multi set lead_count = lead_count+1,r_employee = '".$centerid_dst."',l_employee = '".$centerid."',ibpid = '".$ibpid."',source = '".$pre_source."',vendor = '".$pre_vendor."',mul_proid = '".$row_proid_proid."',mul_proname = '".$l_prodt."',l_prodt = '".$l_prodt."',mul_procode = '".$mul_procode."',ltype = '',ctype = '',fDate = '',fTime = '',dtime = '',fll_details = '',fll_fillby = '' where lead_id='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'";
		  $rs = mysqli_query($con,$str);	
	
	
	
	
									}
	
	//end code
	
	
	
	
	
	
	
	
	/*
	
$date12 = date('Y-m-d H:i:s');
$Date = date('Y-m-d');
$iadd = 'Customer Again Enquiry from '.$source.'';
$ll_details = 'Customer Again Enquiry from '.$source.'';
	$ivoter = 'System';
	$sm_user_fill = 'System';
	$sessionname = 'System';
	$sessionshop = 'System';
	
	
		$dis = "select id,mul_procode from  products where pro_name = '".$l_prodt."'";
									$run_proid = mysqli_query($con,$dis);
									$i = 1;
									$row_proid = mysqli_fetch_array($run_proid);
									
										$mul_proid = $row_proid['id'];
										$row_proid_proid = $row_proid['id'];
										$mul_procode = $row_proid['mul_procode'];
 $str = "update lead_create set log_update_date = '".$date12."',fDate = '".$Date."', fTime = '".$Time."', fll_details = '".$iadd."', fll_fillby = '".$ivoter."', fsub = '".$sub."', status = 'Y' where id='".$leadid."'  AND mul_proid='".$mul_proid."' ";
	      $rs = mysqli_query($con,$str);
		  
	 $str = "update lead_create_multi set log_update_date = '".$date12."',fDate = '".$Date."', fTime = '".$Time."', ltype = '".$ltype."', fll_details = '".$iadd."', fll_fillby = '".$ivoter."', fsub = '".$sub."', status = 'Y' where lead_id='".$leadid."' AND mul_proid='".$mul_proid."' ";
	      $rs = mysqli_query($con,$str);

  $str11="INSERT INTO lead_log(`sub`, `ll_details`, `ll_username`, `ll_shop_id`, `ll_leadcode`, `ll_leadid`, `ll_logno`, `status`, `sm_id`, `admin_id`, `rece_id`, `cp_id`,`mul_proid`,`mul_proname`,`mul_procode`, `Date`, `Time`, `dtime`, `ltype`, `ctype`,`ll_fillby`) 
     SELECT `sub`, '$ll_details', '$sm_user_fill', '$sessionname', '$row_lead_id', '$row_lead_id', `ll_logno`, `status`, `sm_id`, `admin_id`, `rece_id`, `cp_id`,'$row_proid_proid','$l_prodt','$mul_procode', `Date`, `Time`, `dtime`, `ltype`, `ctype`,'$sm_user_fill' FROM lead_log WHERE ll_leadid='".$row_lead_id."'  AND  mul_proid='".$row_proid_proid."'    ORDER BY id DESC  limit 1";
		
		 $rs = mysqli_query($con,$str11);
		
*/

$int="INSERT INTO `enquiry_kasturi` (`fname`, `lname`, `contactno`, `project`, `comment`, `medium`, `email`, `vendor`) VALUES ('".$l_fname."', '".$l_lname."', '".$l_pno."', '".$l_prodt."', '".$l_ld."', '".$source."', '".$l_email."', '".$vendor."')";
$query1 = mysqli_query( $con,$int);
								
	
	

}








}
	
?>

