<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Backend\BookingDetailsController;
use App\Http\Controllers\Backend\CreateLeadController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['middleware' => ['cors', 'json.response']], function () {
    
    #login
    Route::post('/login', 'Auth\ApiAuthController@login')->name('login.api');
    Route::post('/logout', 'Auth\ApiAuthController@logout')->name('logout.api');
	Route::post('/forgotpass', 'Auth\ApiAuthController@forgotpass')->name('logout.api');
    Route::post('/savepass', 'Auth\ApiAuthController@savepass')->name('savepass.api');
    Route::post('/checkotp', 'Auth\ApiAuthController@checkotp')->name('checkotp.api');
  
    #dashboard
    Route::post('/dashboard', 'Backend\DashboardController@index');
    Route::post('/dashboardperformance', 'Backend\PerformanceController@index');
    Route::post('/dashboardview', 'Backend\DashboardInnerController@view');
    Route::post('/projectlist', 'Backend\ProjectListController@index');
    Route::post('/leaddetails', 'Backend\LeadDetailsController@view');
    Route::post('/logdetails', 'Backend\LogDetailsController@view');
    Route::post('/leadmultidetails', 'Backend\LeadMultiDetailsController@view');
    Route::post('/prelead', 'Backend\PreLeadController@index');
    Route::post('/update_dst', 'Backend\LogUpdateEmpController@update_dst');
    Route::post('/update_sm', 'Backend\LogUpdateEmpController@update_sm');
    Route::post('/update_cp', 'Backend\LogUpdateEmpController@update_cp');
    Route::post('/search_ltype', 'Backend\LogInsertPreController@search_ltype');
	 Route::post('/lead_search', 'Backend\LeadSearchController@view');
    Route::post('/search_ctype', 'Backend\LogInsertPreController@search_ctype');
    Route::post('/log_insert', 'Backend\LogInsertController@log_insert');
    Route::post('/add_project', 'Backend\LogAddProController@add_project');
    Route::post('/lead_search', 'Backend\LeadSearchController@view');
   

    Route::any('/booking-details',[BookingDetailsController::class,'view']);
    Route::any('lead-create',[CreateLeadController::class,'store']);

    



});