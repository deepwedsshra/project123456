<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<title>Roha Vatika</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('public/img/fav/apple-icon-57x57.png')); ?>">
	<link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('public/img/fav/apple-icon-60x60.png')); ?>">
	<link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('public/img/fav/apple-icon-72x72.png')); ?>">
	<link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('public/img/fav/apple-icon-76x76.png')); ?>">
	<link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('public/img/fav/apple-icon-114x114.png')); ?>">
	<link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('public/img/fav/apple-icon-120x120.png')); ?>">
	<link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('public/img/fav/apple-icon-144x144.png')); ?>">
	<link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('public/img/fav/apple-icon-152x152.png')); ?>">
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('public/img/fav/apple-icon-180x180.png')); ?>">
	<link rel="icon" type="image/png" sizes="192x192"  href="<?php echo e(asset('public/img/fav/android-icon-192x192.png')); ?>">
	<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('public/img/fav/favicon-32x32.png')); ?>">
	<link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('public/img/fav/favicon-96x96.png')); ?>">
	<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/img/fav/favicon-16x16.png')); ?>">
	<link rel="manifest" href="<?php echo e(asset('public/img/fav/manifest.json')); ?>">
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="img/fav/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap" rel="stylesheet">
	<!-- Bootstrap CSS -->
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.12/css/lightgallery.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('public/css/style.css')); ?>">
</head>

<body>
<header>
   <nav class="navbar navbar-expand-lg navbar-light bg-light" id="mainNav">
       <div class="container"> 
           <a class="navbar-brand" href="index.php">
               <img src="<?php echo e(asset('public/img/logo1.png')); ?>" alt="" class="img-fluid">
           </a>
           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="material-icons menu">menu</span>
            </button>
           <div class="collapse navbar-collapse" id="navbarNavDropdown">
               <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link js-scroll-trigger" href="#home">Home<?php echo e(isset($data1->iname) != '' ? $data1->iname : ''); ?></a>
                    </li>
                   <li class="nav-item">
                       <a class="nav-link js-scroll-trigger" href="#OVERVIEW">OVERVIEW</a>
                   </li>
                   <li class="nav-item"> 
                       <a class="nav-link js-scroll-trigger" href="#AMENITIES">AMENITIES</a>
                   </li>
                   <li class="nav-item"> 
                       <a class="nav-link js-scroll-trigger" href="#LOCATION">LOCATION</a>
                   </li>
                   <!-- <li class="nav-item"> 
                       <a class="nav-link js-scroll-trigger" href="#PLANS">PLANS</a>
                   </li>
                   <li class="nav-item"> 
                       <a class="nav-link js-scroll-trigger" href="#GALLERY">GALLERY</a>
                   </li> -->
                   <li class="nav-item"> 
                       <a class="nav-link js-scroll-trigger" href="#PROJECTPROGRESS">PROJECT PROGRESS  </a>
                   </li>
                   <li class="nav-item"> 
                    <a class="nav-link js-scroll-trigger" href="#Contact">CONTACT </a>
                </li>
               </ul>
           </div>
       </div>
   </nav>
</header>
<section class="mtop" id="home">
    <div class="img">
        <img src="<?php echo e(asset('public/img/01.jpg')); ?>" alt="" class="img-fluid w-100">
    </div>
</section>
<section id="OVERVIEW" class="text-center">
    <div class="container">
        <div class="col-lg-8 p-0 m-auto">
            <h3>
                <span>ROHA GROUP A LEGACY THAT IS BUILT ON COMMITMENT AND TRUST</span>
            </h3>
            <div class="col-lg-8 p-0 m-auto">
                <div class="row my-lg-5 my-3">
                    <div class="col-lg-4">
                        <div class="img">
                            <img src="<?php echo e(asset('public/img/certificate.png')); ?>"  class="img-fluid" alt="">
                        </div>
                        <p>5 DECADES OF<br>EXPERIENCE</p>
                    </div>
                    <div class="col-lg-4">
                        <div class="img">
                            <img src="<?php echo e(asset('public/img/delverd.png')); ?>"  class="img-fluid" alt="">
                        </div>
                        <p>5 MILLION SQ.FT<br>DELIVERED</p>
                    </div>
                    <div class="col-lg-4">
                        <div class="img">
                            <img src="<?php echo e(asset('public/img/upcoming.png')); ?>"  class="img-fluid" alt="">
                        </div>
                        <p>3 MILLION SQ.FT OF<br>UPCOMING DEVELOPMENT</p>
                    </div>
                </div>
            </div>
            <p>
                Roha Realty is the Real Estate arm of the multinational Roha Group, which holds a vast
                expertise across diverse industries. The company has planned, executed and developed
                landmark Residential, Commercial and Warehouse Spaces across India with unmatched
                quality in construction and delivery.
            </p>
        </div>
    </div>
</section>
<section id="AMENITIES" class="text-center">
    <div class="container">
        <div class="col-lg-7 m-auto">
            <h3>
                <span>AMENITIES</span>
            </h3>
           
        </div>
        <div class="row my-lg-5 my-3">
            <div class="col-lg-4">
                <ul>
                    <li>&#8226; ROOFTOP LOUNGE </li>
                    <li>&#8226; GAZEBO AND VIEWING DECK</li>
                    <li>&#8226; TERRACE GARDEN WITH SITTING AREA</li>
                    <li>&#8226; WELL-DESIGNED MULTIPURPOSE AREA</li>
                    <li>&#8226; OPEN PARTY AREA</li>
                    <li>&#8226; MOVIE SCREENING</li>
                    <li>&#8226; AIR CONDITIONED LOBBY WITH BIOMETRIC ACCESS</li>
                </ul>
            </div>
            <div class="col-lg-4">
                <ul>
                    <li>&#8226; VIRTUAL ASSISTANT (ALEXA/GOOGLE) COMPATIBLE WIRING AND CIRCUIT SYSTEMS</li>
                    <li>&#8226; UPVC WINDOW</li>
                    <li>&#8226; USB CHARGING SOCKETS IN ALL SWITCHBOARDS</li>
                    <li>&#8226; REMOTE CONTROL DIGITAL SWITCHES FOR LIVING ROOM AND BEDROOM</li>
                    <li>&#8226; AIR CONDITIONED HOMES</li>
                </ul>
            </div>
            <div class="col-lg-4">
                <ul>
                    <li>&#8226; PROVISION FOR CHIMNEY</li>
                    <li>&#8226; SINK INCINERATORS</li>
                    <li>&#8226; R.O. PROVISION</li>
                    <li>&#8226; INLINE GEYSER PROVISION IN WASHROOM</li>
                    <li>&#8226; MOTION SENSOR LIGHTS IN COMMON PASSAGES</li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-4 mb-lg-0 mb-3">
                <img src="<?php echo e(asset('public/img/amenities/01.jpg')); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-lg-4 mb-lg-0 mb-3">
                <img src="<?php echo e(asset('public/img/amenities/02.jpg')); ?>" class="img-fluid" alt="">
            </div>
            <div class="col-lg-4 mb-lg-0 mb-3">
                <img src="<?php echo e(asset('public/img/amenities/03.jpg')); ?>" class="img-fluid" alt="">
            </div>
        </div>
    </div>
</section>

<section id="LOCATION">
    <div class="container">
        <div class="col-lg-10 p-0 m-auto">
            <h3>
                <span>LOCATION</span>
            </h3>
            <div class="row">
                <div class="col-lg-6">
                    <div class="img">
                        <img src="<?php echo e(asset('public/img/location.jpg')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="txt mt-3 w-100">
                        <div class="mt-2" id="accordion">
                            <div class="card wow animate__fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                                <div class="card-header" id="headingfifteen">
                                    <h5 class="mb-0 mt-0">
                                        <button class="btn-link collapsed" data-toggle="collapse"  data-target="#collapsefifteen" aria-expanded="false"  aria-controls="collapsefifteen"> 
                                            TRANSPORTATION  
                                            <div class="pull-right accor-icon" alt="" draggable="false"></div>
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapsefifteen" class="collapse" aria-labelledby="headingfifteen" data-parent="#accordion">
                                    <div class="card-body">
                                        <ul>
                                            <li>Lokmanya Tilak Terminal - 5 mins</li>
                                            <li>Domestic Airport - 20 mins</li>
                                            <li>International Airport - 30 mins</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card wow animate__fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                                <div class="card-header" id="headingsixeen">
                                    <h5 class="mb-0 mt-0">
                                        <button class="btn-link collapsed" data-toggle="collapse"  data-target="#collapsesixeen" aria-expanded="false"  aria-controls="collapsesixeen">  
                                            CORPORATE HUB
                                            <div class="pull-right accor-icon" alt="" draggable="false"></div>
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapsesixeen" class="collapse" aria-labelledby="headingsixeen" data-parent="#accordion">
                                    <div class="card-body">
                                        <ul>
                                            <li>Commercial & Corporate Offices - 5 mins</li>
                                            <li>Bandra Kurla Complex - 10 mins</li>
                                            <li>Zillion Corporate Hub - 15 mins</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card wow animate__fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                                <div class="card-header" id="headingseventeen">
                                    <h5 class="mb-0 mt-0">
                                        <button class="btn-link collapsed" data-toggle="collapse"  data-target="#collapseseventeen" aria-expanded="false"  aria-controls="collapseseventeen">  
                                            MEDICAL & HOSPITALS
                                            <div class="pull-right accor-icon" alt="" draggable="false"></div>
                                         </button>
                                    </h5>
                                </div>
                                <div id="collapseseventeen" class="collapse" aria-labelledby="headingseventeen" data-parent="#accordion">
                                    <div class="card-body">
                                        <ul>
                                            <li>Kohinoor Hospital - 10 mins</li>
                                            <li>SRV Hospital - 10 mins</li>
                                            <li>Noor Hospital - 15 mins</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card wow animate__fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                                <div class="card-header" id="headingeightteen">
                                    <h5 class="mb-0 mt-0"><button class="btn-link collapsed" data-toggle="collapse"  data-target="#collapseeightteen" aria-expanded="false"  aria-controls="collapseeightteen">  
                                        EDUCATION & RELIGIOUS
                                    <div class="pull-right accor-icon" alt="" draggable="false"></div></button></h5>
                                </div>
                                <div id="collapseeightteen" class="collapse" aria-labelledby="headingeightteen" data-parent="#accordion">
                                    <div class="card-body">
                                        <ul>
                                            <li>K.J.Somaiya College of Engineering - 15 mins</li>
                                            <li>Mumbai University - 20 mins</li>
                                            <li>Asian Heart Institute - 20 mins</li>
                                            <li>Temples and Other Religious Places - 10 mins</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card wow animate__fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                                <div class="card-header" id="headingeightteen1">
                                    <h5 class="mb-0 mt-0">
                                        <button class="btn-link collapsed" data-toggle="collapse"  data-target="#collapseeightteen1" aria-expanded="false"  aria-controls="collapseeightteen1">  
                                            MALLS & ENTERTAINMENT
                                            <div class="pull-right accor-icon" alt="" draggable="false"></div>
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseeightteen1" class="collapse" aria-labelledby="headingeightteen1" data-parent="#accordion">
                                    <div class="card-body">
                                        <ul>
                                            <li>K-Star Mall - 15mins</li>
                                            <li>Pheonix Market City - 15mins</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card wow animate__fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                                <div class="card-header" id="headingeightteen12">
                                    <h5 class="mb-0 mt-0">
                                        <button class="btn-link collapsed" data-toggle="collapse"  data-target="#collapseeightteen12" aria-expanded="false"  aria-controls="collapseeightteen12">  
                                            RAILWAY
                                            <div class="pull-right accor-icon" alt="" draggable="false"></div>
                                        </button>
                                    </h5>
                                </div>
                                <div id="collapseeightteen12" class="collapse" aria-labelledby="headingeightteen12" data-parent="#accordion">
                                    <div class="card-body">
                                        <ul>
                                            <li>Kurla Railway - 5 mins</li>
                                            <li>Ghatkopar Railway - 12 mins</li>
                                            <li>Bandra Railway - 15 mins</li>
                                            <li>Tilak Nagar Railway - 5 mins</li>
                                            <li>Chembur Railway - 10 mins</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- <section id="PLANS">
    <div class="container">
        <h3>
            <span>PLANS</span>
        </h3>
        <div class="col-lg-10 p-0 m-auto mt-3">
            <div class="row">
                <div class="col-lg-4 mb-3">
                    <div class="img">
                        <img src="img/plans/plan1.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="txt mt-lg-3 mt-2">
                       <p>Madison 1 </p>
                       <button type="button" class="btn mt-2" data-toggle="modal" data-target="#enquiry-form" data-backdrop="static" data-keyboard="false">Get Costing</button>
                    </div>
                </div>
                <div class="col-lg-4 mb-3">
                    <div class="img">
                        <img src="img/plans/2bhk_large_small.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="txt mt-lg-3 mt-2">
                       <p>
                            2 BHK Comfortable<br>
                            RERA CARPET : 561 SQ.FT.<br>
                            <small>Wardrobe tucked in wall for extra storage.<br>Kitchen has utility attached.</small>
                       </p>
                       <button type="button" class="btn mt-2" data-toggle="modal" data-target="#enquiry-form" data-backdrop="static" data-keyboard="false">Get Costing</button>
                    </div>
                </div>
                <div class="col-lg-4 mb-3">
                    <div class="img">
                        <img src="img/plans/2bhk_large_small.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="txt mt-lg-3 mt-2">
                       <p>
                            2 BHK Luxury<br>
                            RERA CARPET : 592 SQ.FT.<br>
                            <small>Straight design <br>Same sized bedrooms <br>Same size of living-dining with no partition</small>
                       </p>
                       <button type="button" class="btn mt-2" data-toggle="modal" data-target="#enquiry-form" data-backdrop="static" data-keyboard="false">Get Costing</button>
                    </div>
                </div>
                <div class="col-lg-4 mb-3">
                    <div class="img">
                        <img src="img/plans/2bhk_large_small.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="txt mt-lg-3 mt-2">
                       <p>
                            3 BHK Comfortable<br> RERA CARPET : 756 SQ.FT.<br>
                            <small>
                                90 degree approach to master bedroom for better privacy<br>  Separate storage area behind the door in the master bed<br>  Silent and active zones thoughtfully separated
                            </small>
                       </p>
                       <button type="button" class="btn mt-2"  data-toggle="modal" data-target="#enquiry-form" data-backdrop="static" data-keyboard="false">Get Costing</button>
                    </div>
                </div>
                <div class="col-lg-4 mb-3">
                    <div class="img">
                        <img src="img/plans/2bhk_large_small.jpg" alt="" class="img-fluid">
                    </div>
                    <div class="txt mt-lg-3 mt-2">
                       <p>
                        3 BHK Luxury<br> RERA CARPET : 904 SQ.FT.<br>
                            <small>Each room comes with an enclosed balcony serving a different purpose<br>  Multiple slabs in kitchen for multiple steps in cooking</small>
                       </p>
                       <button type="button" class="btn mt-2"  data-toggle="modal" data-target="#enquiry-form" data-backdrop="static" data-keyboard="false">Get Costing</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->
<!-- <section id="GALLERY">
    <div class="container">
        <h3 class="text-center">
            <span>GALLERY</span>
        </h3>
        <div class="row mt-5">
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/view2.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/view3.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/view4.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/1.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/2.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/3.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/4.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/5.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/6.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-lg-3 mb-3">
                <img src="img/gallery/8.jpg" alt="" class="img-fluid">
            </div>
        </div>
    </div>
</section> -->
<section id="PROJECTPROGRESS">
    <div class="container">
        <h3 class="text-md-center">
            <span>PROJECT PROGRESS</span>
        </h3>
        <div class="row mt-5">
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/01.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/02.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/03.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/04.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/05.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/06.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/07.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-3 col-6 mb-3 text-center">
                <div class="img">
                    <img src="<?php echo e(asset('public/img/Construction/thumb/08.jpg')); ?>" alt="" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
</section>
<section id="Contact">
    <div class="container">
        <h3 class="text-lg-center text-uppercase">
            <span>Contact</span>
        </h3>
        <div class="col-lg-9 m-auto">
            <div class="row">
                <div class="col-lg-6 d-flex align-items-center">
                    <div>
                        <p class="pb-md-2">
                            Site &amp; Office Address:<br> 
                            ROHA VATIKA, Nehru Nagar,<br> 
                            Kurla East, Mumbai, 400024<br> 
                            Maharashtra India.
                        </p>
                        <p class="pb-md-2">
                            Email:<br><a href="mailto:sales@roharealty.com">sales@roharealty.com</a>
                        </p>
                        <p class="pb-md-2">
                            Call Us:<br><a href="tel:+918000220000">+91 8000220000</a>
                        </p>
                        <p class="pb-md-2">
                            MahaRERA Registration No.:<br>P51700018370 are available at website: <a class="text-white " style="text-decoration: underline;text-align:left;" target="_blank" href="https://maharera.mahaonline.gov.in">https://maharera.mahaonline.gov.in</a>
                         </p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <h4>
                        Enquire Now
                    </h4>
                    <div class="w-100">
                        <div id=errmsg></div>
                        <div id=msg></div>
                        <form id="popupEnq" action="javascript:void(0);" method="POST" data-backdrop="static" data-keyboard="false">
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <input type="text" class="px-2 py-2 d-block w-100" placeholder="Name" maxlength="50"
                                        onkeyup="this.value=this.value.replace(/[^a-zA-Z \n\r.]+/g, '');" name="name">
                                </div>
                                <div class="col-12 mb-3">
                                    <input type="email" class="px-2 py-2 d-block w-100" placeholder="Email" name="email"
                                        pattern="[A-Za-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}"
                                        onkeyup="this.value=this.value.replace(/[^a-zA-Z@.[0-9] \n\r.]+/g, '');" >
                                    </div>
                                <div class="col-12 mb-3">
                                    <input type="tel" class="px-2 py-2 d-block w-100" placeholder="Phone" autocomplete="off"
                                    role="presentation" onkeyup="this.value=this.value.replace(/[^0-9]+/g,'');"
                                    onkeypress="if(this.value.length==10) return false;" name="mobile" >
                                </div>
                                <div class="col-12 mb-3">
                                    <input type="hidden" name="source" value="Enquiry Form">
                                    <button type="submit" id="btn-pop" class="mt-3 custom-reg-btn btn" name="submit" value="enquiry">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<footer>
    <div class="container">
        <p class="text-center mb-0 py-3"><small>© Roha Vatika 2022. All Rights Resevered | Designed by GOD</small></p>
    </div>
</footer>
<div class="enquiry-wrapper">
    <div class="enquiry-box" onclick="window.open('tel:+91-9071056711')">
        <div class="call-icon">
            <img src="<?php echo e(asset('public/img/icons/phone.svg')); ?>" alt="">
        </div>
        <div class="call-content">
            <a href="tel:+91-8000220000">+91-8000220000</a>
        </div>
    </div>
    <div class="enquiry-box" data-toggle="modal" data-target="#onload-form">
        <div class="mail-icon">
            <img src="<?php echo e(asset('public/img/icons/email.svg')); ?>" alt="">
        </div>
        <div class="mail-content">
            <a href="#enquiry-form" class="enqForm">Enquiry</a>
        </div>
    </div>
    <div class="enquiry-box" onclick="window.open('https://api.whatsapp.com/send?phone=918000220000&text=Hi,%20I%20would%20like%20to%20enquire%20for%20the%20project%20-%20ROHA%20VATIKA,.')">
        <div class="mail-icon">
            <img src="<?php echo e(asset('public/img/icons/whatsapp.svg')); ?>" alt="">
        </div>
        <div class="mail-content">
            <a href="#">8000220000</a>
        </div>
    </div>
</div>



<!-- ENQUIRY FORM MODAL-->
<div class="modal fade" id="onload-form" tabindex="-1" role="dialog" aria-labelledby="enquiry-formTitle"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title pl-3 text-left" id="exampleModalLongTitle">Please leave your details and we
                    will get in
                    touch with you</h5>
                <button type="button" class="close custom-close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body d-flex flex-column">
                <div id=msg></div>
                <form id="popupOnload" action="javascript:void(0);" method="POST">
                    <div class="row">
                        <div class="col-12 mb-3">
                            <input type="text" class="px-2 py-2 d-block w-100" placeholder="Name" maxlength="50"
                           onkeyup="this.value=this.value.replace(/[^a-zA-Z \n\r.]+/g, '');" name="name"
                           >
                        </div>
                        <div class="col-12 mb-3">
                            <input type="email" class="px-2 py-2 d-block w-100" placeholder="Email" name="email"
                           pattern="[A-Za-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}"
                           onkeyup="this.value=this.value.replace(/[^a-zA-Z@.[0-9] \n\r.]+/g, '');" >
                        </div>
                        <div class="col-12 mb-3">
                            <input type="tel" class="px-2 py-2 d-block w-100" placeholder="Phone" autocomplete="off"
                           role="presentation" onkeyup="this.value=this.value.replace(/[^0-9]+/g,'');"
                           onkeypress="if(this.value.length==10) return false;" name="mobile" >
                        </div>
                        <div class="col-12 mb-3">
                            <input type="hidden" name="source" value="Pageload Form">
                            <button type="submit" id="btn-pop-onload" class="mt-3 custom-reg-btn btn" name="submit" value="pageload">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- ENQUIRY FORM MODAL-->



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightgallery/1.6.12/js/lightgallery-all.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js'></script>
<script src="<?php echo e(asset('public/js/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('public/ajax/js/validation.js')); ?>"></script>
<script src="<?php echo e(asset('public/ajax/js/ajax-form.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.3.17/dist/sweetalert2.all.min.js"></script>
</body>
</html><?php /**PATH D:\xampp74\htdocs\rohavatika\resources\views/home.blade.php ENDPATH**/ ?>